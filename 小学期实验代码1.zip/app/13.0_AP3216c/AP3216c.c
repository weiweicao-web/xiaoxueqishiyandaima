#include <stdio.h>
#include <unistd.h>
#include <string.h>
#include "ohos_init.h"
#include "cmsis_os2.h"
#include "hal_bsp_ap3216c.h"

// 前向声明，解决调用前未定义报错
static void AP3216c_Task(void *arg);

static void AP3216c(void)
{
    osThreadAttr_t options;
    options.name = "AP3216c_Task";
    options.attr_bits = 0U;
    options.cb_mem = NULL;
    options.cb_size = 0U;
    options.stack_mem = NULL;
    options.stack_size = 1024U;
    options.priority = osPriorityNormal;

    osThreadId_t Task1_ID; 
    Task1_ID = osThreadNew((osThreadFunc_t)AP3216c_Task, NULL, &options);
    if (Task1_ID != NULL) {
        printf("Create AP3216c Task Success!\n");
    } else {
        printf("Create AP3216c Task Failed!\n");
    }
}

static void AP3216c_Task(void *arg)
{
    (void)arg; // 消除未使用形参警告
    uint16_t ir = 0, als = 0, ps = 0;

    AP3216C_Init(); // AP3216C三合一传感器初始化（红外/光照/接近）

    while (1)
    {
        AP3216C_ReadData(&ir, &als, &ps);
        printf("ir = %d    als = %d    ps = %d\r\n", ir, als, ps);

        usleep(1000000); // 1秒延时，鸿蒙LiteOS标准延时
    }
}

APP_FEATURE_INIT(AP3216c);