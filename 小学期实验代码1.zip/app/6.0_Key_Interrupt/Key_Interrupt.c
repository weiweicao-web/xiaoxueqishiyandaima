#include <stdio.h>
#include <unistd.h>
#include <stdbool.h>
#include "ohos_init.h"
#include "cmsis_os2.h"
#include "iot_gpio.h"
#include "hi_io.h"

#define KEY_TASK_STACK_SIZE     (1024 * 4)
#define KEY_TASK_PRIO           25

/* 引脚宏定义 */
#define KEY1_PIN        HI_IO_NAME_GPIO_14
#define KEY2_PIN        HI_IO_NAME_GPIO_13
#define LED_PIN         HI_IO_NAME_GPIO_2

#define KEY_DELAY_MS    20

/* 信号量，中断通知任务 */
static osSemaphoreId_t g_key1Sem = NULL;
static osSemaphoreId_t g_key2Sem = NULL;

/* 匹配头文件标准中断回调：void func(char *arg) */
static void Key1_Pressed(char *arg)
{
    (void)arg;
    osSemaphoreRelease(g_key1Sem);
}

static void Key2_Pressed(char *arg)
{
    (void)arg;
    osSemaphoreRelease(g_key2Sem);
}

static void Key_Task(void *arg)
{
    (void)arg;
    IotGpioValue level;

    /* GPIO初始化 */
    IoTGpioInit(KEY1_PIN);
    IoTGpioInit(KEY2_PIN);
    IoTGpioInit(LED_PIN);

    /* 修正引脚复用功能 */
    hi_io_set_func(KEY1_PIN, HI_IO_FUNC_GPIO_14_GPIO);
    hi_io_set_func(KEY2_PIN, HI_IO_FUNC_GPIO_13_GPIO);
    hi_io_set_func(LED_PIN,  HI_IO_FUNC_GPIO_2_GPIO);

    /* 按键内部上拉输入 */
    hi_io_set_pull(KEY1_PIN, HI_IO_PULL_UP);
    hi_io_set_pull(KEY2_PIN, HI_IO_PULL_UP);
    IoTGpioSetDir(KEY1_PIN, IOT_GPIO_DIR_IN);
    IoTGpioSetDir(KEY2_PIN, IOT_GPIO_DIR_IN);

    /* LED输出，默认熄灭 */
    IoTGpioSetDir(LED_PIN, IOT_GPIO_DIR_OUT);
    IoTGpioSetOutputVal(LED_PIN, IOT_GPIO_VALUE0);

    /* 创建二值信号量 */
    g_key1Sem = osSemaphoreNew(1, 0, NULL);
    g_key2Sem = osSemaphoreNew(1, 0, NULL);
    if (g_key1Sem == NULL || g_key2Sem == NULL)
    {
        printf("Semaphore create failed!\n");
        return;
    }

    /* 注册下降沿中断，回调原型匹配 */
    IoTGpioRegisterIsrFunc(KEY1_PIN,
                           IOT_INT_TYPE_EDGE,
                           IOT_GPIO_EDGE_FALL_LEVEL_LOW,
                           Key1_Pressed,
                           NULL);

    IoTGpioRegisterIsrFunc(KEY2_PIN,
                           IOT_INT_TYPE_EDGE,
                           IOT_GPIO_EDGE_FALL_LEVEL_LOW,
                           Key2_Pressed,
                           NULL);

    printf("Key interrupt init done, press KEY1/KEY2\n");

    while (1)
    {
        /* 处理KEY1 */
        if (osSemaphoreAcquire(g_key1Sem, osWaitForever) == osOK)
        {
            usleep(KEY_DELAY_MS * 1000);
            /* 读取引脚电平，补齐第二个参数 */
            IoTGpioGetInputVal(KEY1_PIN, &level);
            if (level == IOT_GPIO_VALUE0)
            {
                IoTGpioSetOutputVal(LED_PIN, IOT_GPIO_VALUE1);
                printf("KEY1 pressed, LED ON\n");
            }
        }

        /* 处理KEY2，非阻塞查询 */
        if (osSemaphoreAcquire(g_key2Sem, 0) == osOK)
        {
            usleep(KEY_DELAY_MS * 1000);
            IoTGpioGetInputVal(KEY2_PIN, &level);
            if (level == IOT_GPIO_VALUE0)
            {
                IoTGpioSetOutputVal(LED_PIN, IOT_GPIO_VALUE0);
                printf("KEY2 pressed, LED OFF\n");
            }
        }
    }
}

static void Key_Interrupt(void)
{
    osThreadAttr_t attr = {0};
    attr.name = "Key_Task";
    attr.stack_size = KEY_TASK_STACK_SIZE;
    attr.priority = KEY_TASK_PRIO;

    osThreadId_t tid = osThreadNew(Key_Task, NULL, &attr);
    if (tid == NULL)
    {
        printf("Create Key_Task failed!\n");
    }
}

APP_FEATURE_INIT(Key_Interrupt);