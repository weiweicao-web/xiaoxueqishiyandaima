#include <stdio.h>
#include "ohos_init.h"
#include "cmsis_os2.h"
#include "iot_gpio.h"
#include "hi_io.h"

#define BUZZ_TASK_STACK_SIZE    1024*4
#define BUZZ_TASK_PRIO          25

// 1. 先定义定时器结构体（所有类型放在最前面，避免未知类型报错）
typedef struct{
    osTimerId_t id;        // 定时器ID
    uint32_t timerDelay;   // 延时时间
    osTimerFunc_t func;    // 回调函数指针
    osTimerType_t type;    // 定时器类型
} TIMER_OBJ_t;

// 全局定时器对象
TIMER_OBJ_t timer_obj;

// 2. 函数前置声明（解决未定义、未识别报错，全部补分号+标准参数）
static void Timer_Callback(void);
static void *Buzzer_Task(const char *arg);
void Buzzer_Timer(void); // 去掉static，给APP_FEATURE_INIT调用

// 定时器回调函数（标准C无参写法 void）
static void Timer_Callback(void)
{
    IoTGpioSetOutputVal(HI_IO_NAME_GPIO_0, IOT_GPIO_VALUE0); // 低电平，蜂鸣器响
    osDelay(1000);                                           // 鸣叫1000ms=1秒，替代sleep(1)
    IoTGpioSetOutputVal(HI_IO_NAME_GPIO_0, IOT_GPIO_VALUE1);  // 高电平，蜂鸣器关闭

    // 关闭定时器：osTimerStop成功返回osOK(0)，判断逻辑修正
    if (osTimerStop(timer_obj.id) == osOK)
    {
        printf("Timer has closed!!!\r\n");
    }
    else
    {
        printf("Timer stop failed!!!\r\n");
    }
}

// 蜂鸣器任务线程
static void *Buzzer_Task(const char *arg)
{
    (void)arg; // 消除未使用参数警告

    // GPIO初始化
    IoTGpioInit(HI_IO_NAME_GPIO_0);
    hi_io_set_func(HI_IO_NAME_GPIO_0, HI_IO_FUNC_GPIO_0_GPIO);
    IoTGpioSetDir(HI_IO_NAME_GPIO_0, IOT_GPIO_DIR_OUT);
    IoTGpioSetOutputVal(HI_IO_NAME_GPIO_0, IOT_GPIO_VALUE1); // 默认关闭蜂鸣器

    // 配置定时器：1U=10ms，200U=2000ms=2秒周期
    timer_obj.timerDelay = 200U;
    timer_obj.func = Timer_Callback;
    timer_obj.type = osTimerPeriodic;

    // 创建定时器
    timer_obj.id = osTimerNew(timer_obj.func, timer_obj.type, NULL, NULL);
    if (timer_obj.id != NULL)
    {
        // 启动定时器，osTimerStart成功返回osOK(0)
        if (osTimerStart(timer_obj.id, timer_obj.timerDelay) == osOK)
        {
            printf("Timer has started!!!\r\n");
        }
        else
        {
            printf("Timer start failed!!!\r\n");
        }
    }
    else
    {
        printf("Timer create failed!!!\r\n");
    }

    // 线程循环阻塞，防止任务退出
    while (1)
    {
        osDelay(1000);
    }
    return NULL;
}

// 入口初始化函数（无static，开机自动执行）
void Buzzer_Timer(void)
{
    osThreadAttr_t attr;
    attr.name = "Buzzer_Task";
    attr.attr_bits = 0U;
    attr.cb_mem = NULL;
    attr.cb_size = 0U;
    attr.stack_mem = NULL;
    attr.stack_size = BUZZ_TASK_STACK_SIZE;
    attr.priority = BUZZ_TASK_PRIO;

    osThreadId_t tid = osThreadNew((osThreadFunc_t)Buzzer_Task, NULL, &attr);
    if (tid == NULL)
    {
        printf("Failed to create Buzzer_Task!\r\n");
    }
    else
    {
        printf("Buzzer_Task create success!\r\n");
    }
}

// 开机自动调用初始化函数
APP_FEATURE_INIT(Buzzer_Timer);