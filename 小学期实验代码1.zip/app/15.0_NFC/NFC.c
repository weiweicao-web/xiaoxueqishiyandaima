#include <stdio.h>
#include <unistd.h>
#include <string.h>
#include <stdlib.h>
#include "ohos_init.h"
#include "cmsis_os2.h"
#include "hal_bsp_nfc.h"
#include "hal_bsp_log.h"

// 前向声明，解决NFC_Task未定义编译报错
static void NFC_Task(void *arg);

static void NFC_ROUTINE(void)
{
    osThreadAttr_t options;
    options.attr_bits = 0U;
    options.cb_mem = NULL;
    options.cb_size = 0U;
    options.stack_mem = NULL;
    options.stack_size = 5120U;
    options.name = "NFC_Task";
    options.priority = osPriorityNormal;

    osThreadId_t Task1_ID = osThreadNew((osThreadFunc_t)NFC_Task, NULL, &options);
    if (Task1_ID == NULL)
    {
        printf("Create NFC_Task Failed!\n");
    }
    else
    {
        printf("Create NFC_Task Success!\n");
    }
}

static void NFC_Task(void *arg)
{
    (void)arg;
    uint8_t ndefLen = 0;
    uint8_t ndef_Header = 0;

    uint8_t ssd[20] = {0};
    uint8_t secret[20] = {0};

    uint8_t Keep_Ssd_Flag = 0;
    uint8_t Keep_Sec_Flag = 0;
    uint8_t Keep_Ssd_long = 0;
    uint8_t Keep_Sec_long = 0;

    // NFC芯片初始化
    if (nfc_Init() != true)
    {
        printf("NFC Init Failed!\n");
        return;
    }
    printf("NFC NT3H I2C Init is succeeded!!!\n");

    osDelay(3000); // 3秒延时，鸿蒙标准接口

    // 读取NFC数据包头部，获取总长度
    if (NT3HReadHeaderNfc(&ndefLen, &ndef_Header) != 0)
    {
        printf("NT3HReadHeaderNfc Failed!\n");
        return;
    }
    ndefLen += NDEF_HEADER_SIZE;
    printf("ndef data total length = %d\n", ndefLen);

    // 动态内存申请存储NFC完整数据包
    uint8_t *ndefBuff = (uint8_t *)malloc(ndefLen + 1U);
    if (ndefBuff == NULL)
    {
        printf("ndefBuff malloc Failed!\n");
        return;
    }
    memset(ndefBuff, 0, ndefLen + 1U);

    // 读取全部NDEF数据
    if (get_NDEFDataPackage(ndefBuff, ndefLen) != 0)
    {
        printf("get_NDEFDataPackage Failed!\n");
        free(ndefBuff);
        return;
    }
    printf("Raw NFC NDEF Buffer: %s\n", ndefBuff);

    // 查找字符'n'的位置，标记WiFi账号起始
    for (size_t i = 0; i < ndefLen; i++)
    {
        if (ndefBuff[i] == 0x6E)
        {
            Keep_Ssd_Flag = i + 1U;
            break;
        }
    }

    // 查找','分隔符，标记密码起始位置
    for (size_t i = 0; i < ndefLen; i++)
    {
        if (ndefBuff[i] == 0x2C)
        {
            Keep_Sec_Flag = i + 1U;
            break;
        }
    }

    // 计算账号、密码有效长度
    Keep_Ssd_long = Keep_Sec_Flag - Keep_Ssd_Flag - 1U;
    Keep_Sec_long = ndefLen - Keep_Sec_Flag;

    // 提取WiFi账号
    if (Keep_Ssd_long < sizeof(ssd))
    {
        for (size_t i = 0; i < Keep_Ssd_long; i++)
        {
            ssd[i] = ndefBuff[i + Keep_Ssd_Flag];
        }
        ssd[Keep_Ssd_long] = '\0'; // 字符串结束符
    }

    // 提取WiFi密码
    if (Keep_Sec_long < sizeof(secret))
    {
        for (size_t i = 0; i < Keep_Sec_long; i++)
        {
            secret[i] = ndefBuff[i + Keep_Sec_Flag];
        }
        secret[Keep_Sec_long] = '\0'; // 字符串结束符
    }

    // 打印解析结果
    printf("WiFi SSID = %s\n", ssd);
    printf("WiFi Password = %s\n", secret);

    free(ndefBuff);

    // 循环常驻不退出
    while (1)
    {
        osDelay(1000);
    }
}

APP_FEATURE_INIT(NFC_ROUTINE);