#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <unistd.h>
#include "ohos_init.h"
#include "cmsis_os2.h"
#include "wifi_connect.h"
#include "lwip/sockets.h"
#include "oc_mqtt.h"
#include "Peripheral.h"
#include "hal_bsp_sht20.h"
#include "hal_bsp_log.h"
#include "hal_bsp_ap3216c.h"
#include "hal_bsp_ssd1306.h"
#include "iot_gpio.h"
#include "hi_io.h"
#include "iot_errno.h"
#include "iot_i2c.h"
#include "hi_i2c.h"
#include "iot_pwm.h"
#include "hi_pwm.h"
#include "iot_uart.h"
#include "hi_uart.h"
#include "cJSON.h"
#include "iot_flash.h"

#define MSGQUEUE_OBJECTS 16
#define CLIENT_ID "66909fb0a559ef622667f972_20240712_0_0_2024072301"
#define USERNAME "66909fb0a559ef622667f972_20240712"
#define PASSWORD "1d7b57c777a78a33e0959451dba455c1f459d9eba1b8ee2b98a72fc9719ee139"

// 枚举和结构体定义
typedef struct {
    char *Buf;
    uint8_t Idx;
} MSGQUEUE_OBJ_t;

typedef enum {
    en_msg_cmd = 0,
    en_msg_report,
} en_msg_type_t;

typedef struct {
    char *request_id;
    char *payload;
} cmd_t;

typedef struct {
    int lum;
    int temp;
    int hum;
    char Longitude[10];
    char Latitude[9];
} report_t;

typedef struct {
    en_msg_type_t msg_type;
    union {
        cmd_t cmd;
        report_t report;
    } msg;
} app_msg_t;

typedef struct {
    int connected;
    int led;
    int motor;
} app_cb_t;

// 全局变量
static app_cb_t g_app_cb;
MSGQUEUE_OBJ_t msg;
osMessageQueueId_t mid_MsgQueue;

char *app_msg_request_id = NULL;
app_msg_t *app_msg_down = NULL;
app_msg_t *app_msg_up = NULL;

// 函数声明
static void deal_cmd_msg(cmd_t *cmd);
static void deal_report_msg(report_t *report);
static void task_main_entry(void *arg);
static void task_sensor_entry(void *arg);
int oc_cmd_get_request_id_len(uint8_t *topic_data, size_t topic_size);
void oc_cmd_rsp_cb(uint8_t *topic_data, size_t topic_size, uint8_t *recv_data, 
                   size_t recv_size, uint8_t **resp_data, size_t *resp_size);

// MQTT主任务
static void MQTT_ROUTINE(void)
{
    mid_MsgQueue = osMessageQueueNew(MSGQUEUE_OBJECTS, sizeof(app_msg_t*), NULL);
    if (mid_MsgQueue == NULL) {
        printf("Failed to create Message Queue!\n");
        return;
    }

    Peripheral_Init();
    SSD1306_CLS();

    osThreadAttr_t attr = {0};
    
    // 创建主任务
    attr.name = "task_main_entry";
    attr.stack_size = 10240;
    attr.priority = 24;
    if (osThreadNew((osThreadFunc_t)task_main_entry, NULL, &attr) == NULL) {
        printf("Failed to create task_main_entry!\n");
    }

    // 创建传感器任务
    attr.name = "task_sensor_entry";
    attr.stack_size = 4096;
    attr.priority = 23;
    if (osThreadNew((osThreadFunc_t)task_sensor_entry, NULL, &attr) == NULL) {
        printf("Failed to create task_sensor_entry!\n");
    }
}

// 主任务入口
static void task_main_entry(void *arg)
{
    app_msg_t *app_msg;
    (void)arg;

    // WiFi连接
    if (WifiConnect("QST-WIFI", "qst654321") != 0) {
        printf("wifi connect failed\n");
        return;
    }

    device_info_init(CLIENT_ID, USERNAME, PASSWORD);
    if (oc_mqtt_init() != 0) {
        printf("MQTT initialization failed\n");
        return;
    }

    oc_set_cmd_rsp_cb(oc_cmd_rsp_cb);

    printf("%s enter wait sensor data\n", __FUNCTION__);
    
    while (1) {
        if (osMessageQueueGet(mid_MsgQueue, &app_msg, NULL, osWaitForever) == osOK) {
            if (app_msg != NULL) {
                printf("G temp %d; hum %d; ps %d\n",
                    app_msg->msg.report.temp,
                    app_msg->msg.report.hum,
                    app_msg->msg.report.lum
                );

                switch (app_msg->msg_type) {
                    case en_msg_cmd:
                        deal_cmd_msg(&app_msg->msg.cmd);
                        free(app_msg_down);
                        free(app_msg_request_id);
                        app_msg_down = NULL;
                        app_msg_request_id = NULL;
                        break;
                    case en_msg_report:
                        deal_report_msg(&app_msg->msg.report);
                        free(app_msg);
                        app_msg = NULL;
                        break;
                    default:
                        break;
                }
            }
        }
    }
}

// 传感器任务入口
static void task_sensor_entry(void *arg)
{
    float temperature = 0, humidity = 0;
    uint16_t ir = 0, als = 0, ps = 0;
    app_msg_t *msg;
    (void)arg;

    while (1) {
        msg = malloc(sizeof(app_msg_t));
        if (msg != NULL) {
            SHT20_ReadData(&temperature, &humidity);
            AP3216C_ReadData(&ir, &als, &ps);

            msg->msg_type = en_msg_report;
            msg->msg.report.hum = (int)humidity;
            msg->msg.report.lum = ps;
            msg->msg.report.temp = (int)temperature;

            printf("P temp %d; hum %d; ps %d\n",
                msg->msg.report.temp,
                msg->msg.report.hum,
                msg->msg.report.lum
            );

            // 发送消息到队列
            if (osMessageQueuePut(mid_MsgQueue, &msg, 0U, 0U) != osOK) {
                free(msg);
            }
            
            sleep(10);
        }
    }
}

// 获取请求ID长度
int oc_cmd_get_request_id_len(uint8_t *topic_data, size_t topic_size)
{
    uint8_t *p = strchr((char*)topic_data, '=');
    if (p != NULL) {
        return (topic_size - (p - topic_data) - 1);
    }
    return 0;
}

// 命令响应回调
void oc_cmd_rsp_cb(uint8_t *topic_data, size_t topic_size, uint8_t *recv_data,
                   size_t recv_size, uint8_t **resp_data, size_t *resp_size)
{
    int len = oc_cmd_get_request_id_len(topic_data, topic_size);
    
    app_msg_request_id = malloc(len + 1);
    if (app_msg_request_id != NULL) {
        memset(app_msg_request_id, 0x00, len + 1);
        memcpy(app_msg_request_id, topic_data + topic_size - len, len);
    }

    app_msg_down = malloc(sizeof(app_msg_t));
    if (app_msg_down != NULL) {
        app_msg_down->msg_type = en_msg_cmd;
        app_msg_down->msg.cmd.payload = (char*)recv_data;
        app_msg_down->msg.cmd.request_id = app_msg_request_id;

        printf("recv data is %.*s\n", (int)recv_size, recv_data);

        if (osMessageQueuePut(mid_MsgQueue, &app_msg_down, 0U, 0U) != osOK) {
            free(app_msg_down);
            free(app_msg_request_id);
            app_msg_down = NULL;
            app_msg_request_id = NULL;
        }
    }

    *resp_data = NULL;
    *resp_size = 0;
}

// 处理命令消息
static void deal_cmd_msg(cmd_t *cmd)
{
    cJSON *obj_root = NULL;
    cJSON *obj_cmdname = NULL;
    cJSON *obj_paras = NULL;
    cJSON *obj_para = NULL;
    int cmdret = 1;
    oc_mqtt_profile_cmdresp_t cmdresp = {0};

    if (cmd == NULL || cmd->payload == NULL) {
        cmdret = -1;
        goto EXIT;
    }

    obj_root = cJSON_Parse(cmd->payload);
    if (obj_root == NULL) {
        cmdret = -1;
        goto EXIT;
    }

    obj_cmdname = cJSON_GetObjectItem(obj_root, "command_name");
    if (obj_cmdname == NULL) {
        cmdret = -2;
        goto EXIT;
    }

    if (strcmp(cJSON_GetStringValue(obj_cmdname), "Control_Valves") == 0) {
        obj_paras = cJSON_GetObjectItem(obj_root, "Paras");
        if (obj_paras == NULL) {
            cmdret = -3;
            goto EXIT;
        }

        obj_para = cJSON_GetObjectItem(obj_paras, "Motor");
        if (obj_para == NULL) {
            cmdret = -4;
            goto EXIT;
        }

        if (strcmp(cJSON_GetStringValue(obj_para), "ON") == 0) {
            g_app_cb.motor = 1;
            Motor_StatusSet_Fan(ON);
            printf("Fan On\n");
        } else {
            g_app_cb.motor = 0;
            Motor_StatusSet_Fan(OFF);
            printf("Fan Off\n");
        }
        cmdret = 0;
    }

EXIT:
    if (obj_root != NULL) {
        cJSON_Delete(obj_root);
    }

    cmdresp.paras = NULL;
    cmdresp.request_id = cmd->request_id;
    cmdresp.ret_code = cmdret;
    cmdresp.ret_name = "Control_Valves";

    oc_mqtt_profile_cmdresp(USERNAME, &cmdresp);
}

// 处理上报消息
static void deal_report_msg(report_t *report)
{
    if (report == NULL) {
        return;
    }

    oc_mqtt_profile_service_t service = {0};
    oc_mqtt_profile_kv_t temperature = {0};
    oc_mqtt_profile_kv_t humidity = {0};

    service.event_time = NULL;
    service.service_id = "Industrial_Internet";
    service.service_property = &temperature;
    service.nxt = NULL;

    temperature.key = "Temperature";
    temperature.value = &report->temp;
    temperature.type = EN_OC_MQTT_PROFILE_VALUE_INT;
    temperature.nxt = &humidity;

    humidity.key = "Humidity";
    humidity.value = &report->hum;
    humidity.type = EN_OC_MQTT_PROFILE_VALUE_INT;
    humidity.nxt = NULL;

    oc_mqtt_profile_propertyreport(USERNAME, &service);
}

// 初始化入口
APP_FEATURE_INIT(MQTT_ROUTINE);