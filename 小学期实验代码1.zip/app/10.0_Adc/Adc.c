#include <stdio.h>
#include <string.h>
#include <unistd.h>
#include <math.h>
#include "ohos_init.h"
#include "cmsis_os2.h"
#include "iot_gpio.h"
#include "hi_io.h"
#include "iot_errno.h"
#include "hi_adc.h"

#define ADC_TASK_STACK_SIZE     1024 * 8
#define ADC_TASK_PRIO           24

// 函数前向声明，解决编译报错
static void ADCTask(void *arg);
static float GetVoltage(void);

/***** 获取电压值函数 *****/
static float GetVoltage(void)
{
    unsigned int ret;
    unsigned short data;

    ret = hi_adc_read(HI_ADC_CHANNEL_6, &data, HI_ADC_EQU_MODEL_8, HI_ADC_CUR_BAIS_DEFAULT, 0xff);
    if (ret != IOT_SUCCESS) {
        printf("ADC Read Fail, ret=%d\n", ret);
        return 0.0f;
    }
    // 分压计算：基准1.8V，外部4倍分压电路
    return (float)data * 1.8f * 4.0f / 4096.0f;
}

static void ADCTask(void *arg)
{
    (void)arg; // 消除未使用参数警告
    float voltage;
    unsigned char keyVal;

    // GPIO13 上拉输入配置
    hi_io_set_pull(HI_IO_NAME_GPIO_13, HI_IO_PULL_UP);
    IoTGpioInit(HI_IO_NAME_GPIO_13);
    IoTGpioSetDir(HI_IO_NAME_GPIO_13, IOT_GPIO_DIR_IN);

    while (1) {
        // 读取ADC电压
        voltage = GetVoltage();
        printf("ADC Voltage: %.3f V | ", voltage);

        // 读取按键GPIO13电平
        IoTGpioGetInputVal(HI_IO_NAME_GPIO_13, &keyVal);
        if (keyVal == 0) {
            printf("KEY GPIO13 Pressed\n");
        } else {
            printf("KEY GPIO13 Release\n");
        }

        usleep(1000000); // 1s刷新一次
    }
}

static void ADCExampleEntry(void)
{
    osThreadAttr_t attr;
    attr.name = "ADCTask";
    attr.attr_bits = 0U;
    attr.cb_mem = NULL;
    attr.cb_size = 0U;
    attr.stack_mem = NULL;
    attr.stack_size = ADC_TASK_STACK_SIZE;
    attr.priority = ADC_TASK_PRIO;

    if (osThreadNew((osThreadFunc_t)ADCTask, NULL, &attr) == NULL) {
        printf("Failed to create ADCTask!\n"); // 修正拼写Falied→Failed
    }
}

APP_FEATURE_INIT(ADCExampleEntry);