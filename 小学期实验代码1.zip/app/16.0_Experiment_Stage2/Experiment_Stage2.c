#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <unistd.h>
#include "ohos_init.h"
#include "cmsis_os2.h"
#include "Peripheral.h"
#include "hal_bsp_sht20.h"
#include "hal_bsp_ap3216c.h"
#include "hal_bsp_ssd1306.h"
#include "hal_bsp_nfc.h"
#include "iot_gpio.h"
#include "hi_io.h"
#include "iot_errno.h"
#include "iot_i2c.h"
#include "hi_i2c.h"
#include "hi_adc.h"
#include "config.h"
#include "mpu6050.h"

// 前向声明
static void Stage2_Task1(void *arg);
static void Stage2_Task2(void *arg);
static void Stage2_Task3(void *arg);
static float Get_Voltage(void);

osSemaphoreId_t sem1;

uint8_t displayBuff_0[20] = {0};
uint8_t displayBuff_1[20] = {0};
uint8_t displayBuff_2[20] = {0};
uint8_t displayBuff_3[20] = {0};

float temperature = 0.0f;
float humidity = 0.0f;
uint16_t ir = 0, als = 0, ps = 0;
hi_s16 mpu_dates[7] = {0};
hi_u8 mpu_ds[14] = {0};
hi_u8 mpu_ln = 14;

#define IoT_KEY2_GPIO_13        HI_IO_NAME_GPIO_13

static void Experiment_Stage2(void)
{
    osThreadAttr_t attr;
    attr.attr_bits = 0U;
    attr.cb_mem = NULL;
    attr.cb_size = 0U;
    attr.stack_mem = NULL;
    attr.stack_size = 4096U;

    attr.name = "Stage2_Task1";
    attr.priority = osPriorityNormal;
    osThreadId_t t1 = osThreadNew((osThreadFunc_t)Stage2_Task1, NULL, &attr);
    if(t1 == NULL){
        printf("Failed to create Stage2_Task1!\n");
    }

    attr.name = "Stage2_Task2";
    osThreadId_t t2 = osThreadNew((osThreadFunc_t)Stage2_Task2, NULL, &attr);
    if(t2 == NULL){
        printf("Failed to create Stage2_Task2!\n");
    }

    attr.name = "Stage2_Task3";
    osThreadId_t t3 = osThreadNew((osThreadFunc_t)Stage2_Task3, NULL, &attr);
    if(t3 == NULL){
        printf("Failed to create Stage2_Task3!\n");
    }

    sem1 = osSemaphoreNew(4U, 0U, NULL);
    if(sem1 == NULL){
        printf("Failed to create Semaphore1!\n");
    }
}

static void Stage2_Task1(void *arg)
{
    (void)arg;
    float Voltage;
    hi_u32 ret;

    // IO、I2C引脚初始化
    Peripheral_Init();
    hi_io_set_pull(IoT_KEY2_GPIO_13, HI_IO_PULL_UP);
    hi_io_set_func(HI_IO_NAME_GPIO_10, HI_IO_FUNC_GPIO_10_I2C0_SDA);
    hi_io_set_func(HI_IO_NAME_GPIO_14, HI_IO_FUNC_GPIO_14_I2C0_SCL);
    ret = hi_i2c_init(HI_I2C_IDX_0, 400000U);
    if(ret != HI_ERR_SUCCESS) printf("[I2C0 Init Failed]\n");

    SSD1306_Init();
    SSD1306_CLS();
    AP3216C_Init();
    SHT20_Init();
    Mpu6050_Init();

    while(1){
        // 释放2个信号量，唤醒Task2、Task3
        osSemaphoreRelease(sem1);
        osSemaphoreRelease(sem1);
        printf("Sht20_Task1 has released sem1!\n");

        // 读取ADC电压
        Voltage = Get_Voltage();
        // 读取三合一AP3216C
        AP3216C_ReadData(&ir, &als, &ps);
        // 读取MPU6050
        Mpu6050_Measure_By(mpu_ds, mpu_ln);
        Mpu6050_Measure_Sh(mpu_dates);
        // SHT20温湿度
        SHT20_ReadData(&temperature, &humidity);

        printf("ir=%d als=%d ps=%d, temp=%.2f hum=%.2f, accel x=%d y=%d z=%d gyro x=%d y=%d z=%d\n",
               ir,als,ps, temperature,humidity,
               mpu_dates[0],mpu_dates[1],mpu_dates[2],
               mpu_dates[3],mpu_dates[4],mpu_dates[5]);

        osDelay(1000);
    }
}

static void Stage2_Task2(void *arg)
{
    (void)arg;
    osDelay(3000);
    SSD1306_CLS();
    uint8_t hour=0,min=0,sec=0;
    while(1){
        osSemaphoreAcquire(sem1, osWaitForever);
        // OLED刷新显示三合一、温湿度
        sprintf((char *)displayBuff_0,"ALS:%d IR:%d PS:%d",als,ir,ps);
        sprintf((char *)displayBuff_1,"T:%.2f H:%.2f",temperature,humidity);
        SSD1306_ShowStr(0,0,displayBuff_0,16);
        SSD1306_ShowStr(0,2,displayBuff_1,16);
        sec++;
        if(sec>59){sec=0;min++;}
        if(min>59){min=0;hour++;}
        if(hour>23)hour=0;
        sprintf((char *)displayBuff_2,"%02d:%02d:%02d",hour,min,sec);
        SSD1306_ShowStr(0,4,displayBuff_2,16);
        osDelay(100);
    }
}

static void Stage2_Task3(void *arg)
{
    (void)arg;
    uint8_t ndefLen = 0;
    uint8_t ndef_Header = 0;
    uint8_t ssd[20]={0};
    uint8_t secret[20]={0};
    uint8_t Keep_Ssd_Flag = 0;
    uint8_t Keep_Sec_Flag = 0;
    uint8_t Keep_Ssd_long = 0;
    uint8_t Keep_Sec_long = 0;

    osDelay(1000);

    if(nfc_Init() != true){
        printf("[nfc_Init] Failed\n");
        return;
    }
    printf("I2C SHT20 Init is succeeded!!!\n");

    while(1)
    {
        osSemaphoreAcquire(sem1, osWaitForever);
        if(NT3HReadHeaderNfc(&ndefLen,&ndef_Header) != 0 ){
            printf("NT3HReadHeaderNfc Failed\n");
            osDelay(1000);
            continue;
        }
        ndefLen += NDEF_HEADER_SIZE;
        uint8_t *ndefBuff = (uint8_t *)malloc(ndefLen+1U);
        if(ndefBuff == NULL){
            printf("ndefBuff malloc Failed!\n");
            osDelay(1000);
            continue;
        }
        memset(ndefBuff,0,ndefLen+1U);
        if(get_NDEFDataPackage(ndefBuff,ndefLen) != 0){
            printf("get_NDEFDataPackage Failed\n");
            free(ndefBuff);
            osDelay(1000);
            continue;
        }
        // 分割账号密码 n 开头 ,分割
        for(uint8_t i=0;i<ndefLen;i++){
            if(ndefBuff[i]==0x6E){
                Keep_Ssd_Flag = i+1;
                break;
            }
        }
        for(uint8_t i=0;i<ndefLen;i++){
            if(ndefBuff[i]==0x2C){
                Keep_Sec_Flag = i+1;
                break;
            }
        }
        Keep_Ssd_long = Keep_Sec_Flag - Keep_Ssd_Flag -1;
        Keep_Sec_long = ndefLen - Keep_Sec_Flag;
        memset(ssd,0,sizeof(ssd));
        memset(secret,0,sizeof(secret));
        for(uint8_t i=0;i<Keep_Ssd_long;i++) ssd[i] = ndefBuff[i+Keep_Ssd_Flag];
        for(uint8_t i=0;i<Keep_Sec_long;i++) secret[i] = ndefBuff[i+Keep_Sec_Flag];
        printf("WiFi SSID = %s\nWiFi Password = %s\n",ssd,secret);
        free(ndefBuff);
        osDelay(1000);
    }
}

float Get_Voltage(void)
{
    unsigned int ret;
    unsigned short data = 0;
    ret = hi_adc_read(HI_ADC_CHANNEL_6, &data, HI_ADC_EQU_MODEL_8, HI_ADC_CUR_BAIS_DEFAULT, 0xff);
    if (ret != HI_ERR_SUCCESS)
    {
        printf("[hi_adc_read] ADC Read Fail\n");
        return 0.0f;
    }
    return (float)data * 1.8f * 4.0f / 4096.0f;
}

APP_FEATURE_INIT(Experiment_Stage2);