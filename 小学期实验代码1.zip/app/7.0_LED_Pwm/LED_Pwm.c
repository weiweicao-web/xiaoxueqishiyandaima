#include <stdio.h>
#include <string.h>
#include <unistd.h>
#include "ohos_init.h"
#include "cmsis_os2.h"
#include "iot_gpio.h"
#include "hi_io.h"
#include "iot_pwm.h"
#include "hi_pwm.h"

/* 消息队列配置 */
#define MSGQUEUE_OBJECTS    16
#define MSG_BUF_LEN         100

/* PWM硬件配置宏 */
#define PWM_GPIO_PIN        HI_IO_NAME_GPIO_6
#define PWM_FUNC            HI_IO_FUNC_GPIO_6_PWM3_OUT
#define PWM_PORT            HI_PWM_PORT_PWM3
#define PWM_PERIOD          40000U

/* 消息结构体：改用字符数组，避免裸指针野地址风险 */
typedef struct {
    char Buf[MSG_BUF_LEN];
    uint8_t Idx;
} MSGQUEUE_OBJ_t_rx;

osMessageQueueId_t g_msgQueueId = NULL;

/**
 * PWM渐变呼吸灯任务
 */
static void Pwm_Task1(void *arg)
{
    (void)arg;
    uint32_t i;

    // GPIO初始化并复用为PWM
    IoTGpioInit(PWM_GPIO_PIN);
    hi_io_set_func(PWM_GPIO_PIN, PWM_FUNC);
    IoTGpioSetDir(PWM_GPIO_PIN, IOT_GPIO_DIR_OUT);

    IoTPwmInit(PWM_PORT);
    printf("PWM3 breath task start, pin GPIO6\n");

    while (1)
    {
        printf("%s running, brightness up\n", __FUNCTION__);
        for (i = 1; i < 100; i++)
        {
            IoTPwmStart(PWM_PORT, i, PWM_PERIOD);
            usleep(10000);
        }
        sleep(1);

        printf("%s running, brightness down\n", __FUNCTION__);
        for (i = 100; i > 0; i--)
        {
            IoTPwmStart(PWM_PORT, i, PWM_PERIOD);
            usleep(10000);
        }
    }
}

/**
 * 消息队列发送任务
 */
static void Pwm_Task2(void *arg)
{
    (void)arg;
    osStatus_t status;
    MSGQUEUE_OBJ_t_rx sendMsg;
    uint8_t msgCnt = 0;

    sleep(1);
    printf("Msg send task ready\n");

    while (1)
    {
        printf("%s running, send message\n", __FUNCTION__);
        // 格式化字符串拷贝到结构体数组，杜绝裸指针问题
        snprintf(sendMsg.Buf, MSG_BUF_LEN, "Hello OpenHarmony! Count:%d", msgCnt++);
        sendMsg.Idx = msgCnt;

        // 发送消息，永久等待队列有空位
        status = osMessageQueuePut(g_msgQueueId, &sendMsg, 0U, osWaitForever);
        if (status != osOK)
        {
            printf("Message Queue Put Failed, status:%d\n", status);
        }
        sleep(3);
    }
}

/**
 * 消息队列接收任务
 */
static void Pwm_Task3(void *arg)
{
    (void)arg;
    osStatus_t status;
    MSGQUEUE_OBJ_t_rx recvMsg;

    printf("Msg receive task ready\n");

    while (1)
    {
        printf("%s running, wait message\n", __FUNCTION__);
        // 永久阻塞等待消息，无消息不刷屏报错
        status = osMessageQueueGet(g_msgQueueId, &recvMsg, NULL, osWaitForever);
        if (status == osOK)
        {
            printf("Recv Msg[%d]: %s\n", recvMsg.Idx, recvMsg.Buf);
        }
        else
        {
            printf("Message Queue Get Failed, status:%d\n", status);
        }
    }
}

static void LED_Pwm(void)
{
    // 创建消息队列：每个消息大小为结构体长度
    g_msgQueueId = osMessageQueueNew(MSGQUEUE_OBJECTS, sizeof(MSGQUEUE_OBJ_t_rx), NULL);
    if (g_msgQueueId == NULL)
    {
        printf("Failed to create Message Queue!\n");
        return;
    }

    osThreadAttr_t attr = {0};
    attr.stack_size = 1024 * 4;
    attr.priority = 25;

    // 创建PWM呼吸灯任务
    attr.name = "Pwm_Task1";
    if (osThreadNew(Pwm_Task1, NULL, &attr) == NULL)
    {
        printf("Failed to create Pwm_Task1!\n");
    }

    // 创建消息发送任务
    attr.name = "Pwm_Task2";
    if (osThreadNew(Pwm_Task2, NULL, &attr) == NULL)
    {
        printf("Failed to create Pwm_Task2!\n");
    }

    // 创建消息接收任务
    attr.name = "Pwm_Task3";
    if (osThreadNew(Pwm_Task3, NULL, &attr) == NULL)
    {
        printf("Failed to create Pwm_Task3!\n");
    }
}

APP_FEATURE_INIT(LED_Pwm);