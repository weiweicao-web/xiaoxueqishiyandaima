#include <stdio.h>
#include "ohos_init.h"
#include "cmsis_os2.h"
#include "iot_gpio.h"
#include "hi_io.h"

#define FAN_TASK_STACK_SIZE     1024*4
#define FAN_TASK1_PRIO          26
#define FAN_TASK2_PRIO          25
#define FAN_TASK3_PRIO          24

// 互斥锁全局ID
osMutexId_t mutex_id;

// ========== 前置函数声明（解决undeclared报错核心） ==========
static void *Fan_Task1(const char *arg);
static void *Fan_Task2(const char *arg);
static void *Fan_Task3(const char *arg);
void Fan_Mutex(void);  // 去掉static，给APP_FEATURE_INIT调用

// ========== 任务1：高优先级，占用互斥锁控制风扇开启 ==========
static void *Fan_Task1(const char *arg)
{
    (void)arg; // 消除参数未使用警告

    // 初始化风扇GPIO
    IoTGpioInit(HI_IO_NAME_GPIO_1);
    hi_io_set_func(HI_IO_NAME_GPIO_1, HI_IO_FUNC_GPIO_1_GPIO);
    IoTGpioSetDir(HI_IO_NAME_GPIO_1, IOT_GPIO_DIR_OUT);
    IoTGpioSetOutputVal(HI_IO_NAME_GPIO_1, IOT_GPIO_VALUE1); // 默认风扇关闭

    osDelay(1000); // 替代sleep(1)，延时1s

    while (1)
    {
        // 永久等待获取互斥锁
        osMutexAcquire(mutex_id, osWaitForever);

        printf("%s is Running!!!\r\n", __FUNCTION__);
        IoTGpioSetOutputVal(HI_IO_NAME_GPIO_1, IOT_GPIO_VALUE0); // 风扇开
        osDelay(5000); // 占用锁5秒，其他需要锁的任务阻塞

        osMutexRelease(mutex_id); // 释放互斥锁
        osDelay(1000);
    }
    return NULL;
}

// ========== 任务2：中优先级，不使用互斥锁，不受锁阻塞 ==========
static void *Fan_Task2(const char *arg)
{
    (void)arg;
    osDelay(1000);

    while (1)
    {
        printf("%s is Running!!!\r\n", __FUNCTION__);
        osDelay(1000);
    }
    return NULL;
}

// ========== 任务3：低优先级，需要互斥锁控制风扇关闭 ==========
static void *Fan_Task3(const char *arg)
{
    (void)arg;
    while (1)
    {
        osMutexAcquire(mutex_id, osWaitForever);

        printf("%s is Running!!!\r\n", __FUNCTION__);
        IoTGpioSetOutputVal(HI_IO_NAME_GPIO_1, IOT_GPIO_VALUE1); // 风扇关
        osDelay(3000); // 占用锁3秒

        osMutexRelease(mutex_id);
        osDelay(1000);
    }
    return NULL;
}

// ========== 初始化入口函数（开机自动执行） ==========
void Fan_Mutex(void)
{
    osThreadAttr_t attr;
    attr.attr_bits = 0U;
    attr.cb_mem = NULL;
    attr.cb_size = 0U;
    attr.stack_mem = NULL;
    attr.stack_size = FAN_TASK_STACK_SIZE;

    // 创建互斥锁
    mutex_id = osMutexNew(NULL);
    if (mutex_id == NULL)
    {
        printf("Failed to create mutex!!!\r\n");
        return;
    }

    // 创建任务1 高优先级
    attr.name = "Fan_Task1";
    attr.priority = FAN_TASK1_PRIO;
    if (osThreadNew((osThreadFunc_t)Fan_Task1, NULL, &attr) == NULL)
    {
        printf("Failed to create Fan_Task1!\r\n");
    }

    // 创建任务2 中优先级（不抢锁）
    attr.name = "Fan_Task2";
    attr.priority = FAN_TASK2_PRIO;
    if (osThreadNew((osThreadFunc_t)Fan_Task2, NULL, &attr) == NULL)
    {
        printf("Failed to create Fan_Task2!\r\n");
    }

    // 创建任务3 低优先级
    attr.name = "Fan_Task3";
    attr.priority = FAN_TASK3_PRIO;
    if (osThreadNew((osThreadFunc_t)Fan_Task3, NULL, &attr) == NULL)
    {
        printf("Failed to create Fan_Task3!\r\n");
    }
}

// 系统开机自动调用初始化函数
APP_FEATURE_INIT(Fan_Mutex);