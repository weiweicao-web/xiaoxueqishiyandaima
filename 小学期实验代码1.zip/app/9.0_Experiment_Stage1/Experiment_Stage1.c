#include <stdio.h>
#include <string.h>
#include <unistd.h>
#include "ohos_init.h"
#include "cmsis_os2.h"
#include "iot_gpio.h"
#include "hi_io.h"
#include "iot_pwm.h"
#include "hi_pwm.h"
#include "iot_uart.h"
#include "hi_uart.h"
#include "iot_errno.h"

#define UART_BUFF_SIZE      1000    // 串口缓冲区大小
#define MSGQUEUE_OBJECTS    16      // 消息队列最大缓存个数
#define MSG_BUF_LEN         128     // 消息单条数据长度
#define UART_DEV_ID         HI_UART_IDX_2
#define PWM_DEV_PORT        HI_PWM_PORT_PWM3

// 定时器结构体
typedef struct{
    osTimerId_t id;
    uint32_t    timerDelayMs;   // 单位ms
    osTimerFunc_t func;
    osTimerType_t type;
}TIMER_OBJ_t;

// 消息队列：改用内存拷贝，不传递裸指针
typedef struct{
    char data[MSG_BUF_LEN];
}MSGQUEUE_OBJ_t_rx;

// 全局句柄
osMessageQueueId_t mid_MsgQueue;
osMutexId_t mutex_id;

// 函数前置声明（解决隐式声明编译警告）
static void Peripheral_Init(void);
static void Stage1_Task1(void *arg);
static void Stage1_Task2(void *arg);
static void Stage1_Task3(void *arg);
static void F1_Pressed(char *arg);
static void F2_Pressed(char *arg);
static void Timer1_Callback(void *arg);

/************************ 外设初始化 ************************/
static void Peripheral_Init(void)
{
    // GPIO初始化
    IoTGpioInit(HI_IO_NAME_GPIO_0);    // BEEP
    IoTGpioInit(HI_IO_NAME_GPIO_1);    // FAN
    IoTGpioInit(HI_IO_NAME_GPIO_2);    // R
    IoTGpioInit(HI_IO_NAME_GPIO_6);    // PWM
    IoTGpioInit(HI_IO_NAME_GPIO_7);    // G
    IoTGpioInit(HI_IO_NAME_GPIO_8);    // B
    IoTGpioInit(HI_IO_NAME_GPIO_11);   // UART2_TX
    IoTGpioInit(HI_IO_NAME_GPIO_12);   // UART2_RX
    IoTGpioInit(HI_IO_NAME_GPIO_13);   // KEY F2
    IoTGpioInit(HI_IO_NAME_GPIO_14);   // KEY F1

    // UART2引脚复用
    hi_io_set_func(HI_IO_NAME_GPIO_11, HI_IO_FUNC_GPIO_11_UART2_TXD);
    hi_io_set_func(HI_IO_NAME_GPIO_12, HI_IO_FUNC_GPIO_12_UART2_RXD);

    // UART参数配置
    IotUartAttribute uart_attr = {
        .baudRate = 9600,
        .dataBits = IOT_UART_DATA_BIT_8,
        .stopBits = IOT_UART_STOP_BIT_1,
        .parity = IOT_UART_PARITY_NONE,
        .rxBlock = IOT_UART_BLOCK_STATE_BLOCK,
    };
    IoTUartInit(UART_DEV_ID, &uart_attr);

    // 风扇GPIO1：低电平开启，默认关闭
    hi_io_set_func(HI_IO_NAME_GPIO_1, HI_IO_FUNC_GPIO_1_GPIO);
    IoTGpioSetDir(HI_IO_NAME_GPIO_1, IOT_GPIO_DIR_OUT);
    IoTGpioSetOutputVal(HI_IO_NAME_GPIO_1, 1);

    // RGB R/G/B 高电平亮，默认熄灭
    hi_io_set_func(HI_IO_NAME_GPIO_2, HI_IO_FUNC_GPIO_2_GPIO);
    IoTGpioSetDir(HI_IO_NAME_GPIO_2, IOT_GPIO_DIR_OUT);
    IoTGpioSetOutputVal(HI_IO_NAME_GPIO_2, 0);

    hi_io_set_func(HI_IO_NAME_GPIO_7, HI_IO_FUNC_GPIO_7_GPIO);
    IoTGpioSetDir(HI_IO_NAME_GPIO_7, IOT_GPIO_DIR_OUT);
    IoTGpioSetOutputVal(HI_IO_NAME_GPIO_7, 0);

    hi_io_set_func(HI_IO_NAME_GPIO_8, HI_IO_FUNC_GPIO_8_GPIO);
    IoTGpioSetDir(HI_IO_NAME_GPIO_8, IOT_GPIO_DIR_OUT);
    IoTGpioSetOutputVal(HI_IO_NAME_GPIO_8, 0);

    // 蜂鸣器GPIO0：低电平响，高电平关闭，默认关闭
    hi_io_set_func(HI_IO_NAME_GPIO_0, HI_IO_FUNC_GPIO_0_GPIO);
    IoTGpioSetDir(HI_IO_NAME_GPIO_0, IOT_GPIO_DIR_OUT);
    IoTGpioSetOutputVal(HI_IO_NAME_GPIO_0, 1);

    // PWM引脚初始化
    hi_io_set_func(HI_IO_NAME_GPIO_6, HI_IO_FUNC_GPIO_6_PWM3_OUT);
    IoTGpioSetDir(HI_IO_NAME_GPIO_6, IOT_GPIO_DIR_OUT);
    IoTPwmInit(PWM_DEV_PORT);

    // F1按键 GPIO14 下降沿中断 上拉输入
    hi_io_set_func(HI_IO_NAME_GPIO_14, HI_IO_FUNC_GPIO_14_GPIO);
    IoTGpioSetDir(HI_IO_NAME_GPIO_14, IOT_GPIO_DIR_IN);
    hi_io_set_pull(HI_IO_NAME_GPIO_14, HI_IO_PULL_UP);
    IoTGpioRegisterIsrFunc(HI_IO_NAME_GPIO_14, IOT_INT_TYPE_EDGE,
                           IOT_GPIO_EDGE_FALL_LEVEL_LOW, F1_Pressed, NULL);

    // F2按键 GPIO13 修复：上拉引脚改为GPIO13
    hi_io_set_func(HI_IO_NAME_GPIO_13, HI_IO_FUNC_GPIO_13_GPIO);
    IoTGpioSetDir(HI_IO_NAME_GPIO_13, IOT_GPIO_DIR_IN);
    hi_io_set_pull(HI_IO_NAME_GPIO_13, HI_IO_PULL_UP);
    IoTGpioRegisterIsrFunc(HI_IO_NAME_GPIO_13, IOT_INT_TYPE_EDGE,
                           IOT_GPIO_EDGE_FALL_LEVEL_LOW, F2_Pressed, NULL);
}

/************************ 按键中断回调 ************************/
static void F1_Pressed(char *arg)
{
    (void)arg;
    // G B 亮
    IoTGpioSetOutputVal(HI_IO_NAME_GPIO_7, 1);
    IoTGpioSetOutputVal(HI_IO_NAME_GPIO_8, 1);
    printf("KEY1 Pressed!\r\n");
}

static void F2_Pressed(char *arg)
{
    (void)arg;
    // G B 灭
    IoTGpioSetOutputVal(HI_IO_NAME_GPIO_7, 0);
    IoTGpioSetOutputVal(HI_IO_NAME_GPIO_8, 0);
    printf("KEY2 Pressed!\r\n");
}

/************************ 定时器回调（禁止阻塞！）************************/
static void Timer1_Callback(void *arg)
{
    (void)arg;
    MSGQUEUE_OBJ_t_rx msg;
    snprintf(msg.data, MSG_BUF_LEN, "BEEP_TRIGGER");
    // 定时器上下文等待时间设0，不阻塞中断
    osMessageQueuePut(mid_MsgQueue, &msg, 0U, 0U);
}

/************************ Task1：串口收发 + PWM渐变呼吸 ************************/
static void Stage1_Task1(void *arg)
{
    (void)arg;
    int ret;
    uint32_t i = 0;
    // 局部栈缓冲区减小，超大缓存建议全局static
    static uint8_t uart_buff_recv[UART_BUFF_SIZE] = {0};
    const char *test_data = "It is UART TX Data!\r\n";

    // 串口收发只在初始化执行一次，不再长期持有互斥锁阻塞其他任务
    ret = IoTUartWrite(UART_DEV_ID, (unsigned char *)test_data, strlen(test_data));
    printf("UART TX ret = %d\r\n", ret);
    if (ret <= 0)
    {
        printf("Uart2 TX Data Failed, Error = %d\r\n", ret);
    }
    usleep(100000);

    ret = IoTUartRead(UART_DEV_ID, uart_buff_recv, sizeof(uart_buff_recv) - 1);
    if (ret > 0)
    {
        uart_buff_recv[ret] = '\0';
        printf("Uart2 RX Data: [%s]\r\n", uart_buff_recv);
    }
    else
    {
        printf("Uart2 RX Data Failed, Error = %d\r\n", ret);
    }
    memset(uart_buff_recv, 0, sizeof(uart_buff_recv));

    while (1)
    {
        printf("%s is Running!\r\n", __FUNCTION__);

        // 占空比从小到大
        for (i = 1; i < 100; i++)
        {
            IoTPwmStart(PWM_DEV_PORT, i, 40000);
            usleep(10000);
        }
        sleep(1);

        // 占空比从大到小
        for (i = 100; i > 0; i--)
        {
            IoTPwmStart(PWM_DEV_PORT, i, 40000);
            usleep(10000);
        }
        sleep(1);
    }
}

/************************ Task2：风扇控制 + 消息队列发送 ************************/
static void Stage1_Task2(void *arg)
{
    (void)arg;
    osStatus_t status = osError;
    MSGQUEUE_OBJ_t_rx Msgq;

    sleep(3);
    // 短时持有锁操作GPIO，立即释放，不长期占用
    osMutexAcquire(mutex_id, osWaitForever);
    IoTGpioSetOutputVal(HI_IO_NAME_GPIO_1, 0); // 开风扇
    osMutexRelease(mutex_id);
    printf("Fan Open!\r\n");

    while (1)
    {
        printf("%s is Running!\r\n", __FUNCTION__);
        snprintf(Msgq.data, MSG_BUF_LEN, "It is MsgQ Data for testing message queue");
        status = osMessageQueuePut(mid_MsgQueue, &Msgq, 0U, 0U);
        if (status != osOK)
        {
            printf("Message Queue Put failed, status = %d\r\n", status);
        }
        sleep(3);
    }
}

/************************ Task3：消息队列接收 + 定时器蜂鸣器处理 ************************/
static void Stage1_Task3(void *arg)
{
    (void)arg;
    osStatus_t status;
    TIMER_OBJ_t timer_obj;
    MSGQUEUE_OBJ_t_rx Msgq;

    // Hi3861 osTimer单位：1tick = 10ms，100tick=1s
    timer_obj.timerDelayMs = 1000;
    timer_obj.func = Timer1_Callback;
    timer_obj.type = osTimerPeriodic;

    // 创建并启动定时器
    timer_obj.id = osTimerNew(timer_obj.func, timer_obj.type, NULL, NULL);
    if (timer_obj.id != NULL)
    {
        status = osTimerStart(timer_obj.id, timer_obj.timerDelayMs / 10);
        if (status != osOK)
        {
            printf("Timer could not be started!\r\n");
        }
    }

    while (1)
    {
        printf("%s is Running!\r\n", __FUNCTION__);
        status = osMessageQueueGet(mid_MsgQueue, &Msgq, NULL, osWaitForever);
        if (status == osOK)
        {
            // 判断是否为蜂鸣器触发消息
            if (strstr(Msgq.data, "BEEP_TRIGGER") != NULL)
            {
                printf("-------------Buzzer is ON-------------\r\n");
                IoTGpioSetOutputVal(HI_IO_NAME_GPIO_0, 0);
                sleep(1);
                IoTGpioSetOutputVal(HI_IO_NAME_GPIO_0, 1);
                printf("-------------Buzzer is OFF-------------\r\n");
            }
            else
            {
                printf("Message Queue Get Data: [%s]\r\n", Msgq.data);
            }
        }
        else
        {
            printf("Message Queue Get failed, status = %d\r\n", status);
        }
    }
}

/************************ 应用入口初始化 ************************/
static void Experiment_Stage1(void)
{
    // 外设初始化
    Peripheral_Init();

    // 创建消息队列：每个消息大小为MSGQUEUE_OBJ_t_rx
    mid_MsgQueue = osMessageQueueNew(MSGQUEUE_OBJECTS, sizeof(MSGQUEUE_OBJ_t_rx), NULL);
    if (mid_MsgQueue == NULL)
    {
        printf("Failed to create Message Queue!\r\n");
        return;
    }

    // 创建互斥锁
    mutex_id = osMutexNew(NULL);
    if (mutex_id == NULL)
    {
        printf("Failed to create mutex!\r\n");
        return;
    }

    // 统一线程属性
    osThreadAttr_t attr = {
        .attr_bits = 0U,
        .cb_mem = NULL,
        .cb_size = 0U,
        .stack_mem = NULL,
        .stack_size = 4096,
    };

    // 创建任务1
    attr.name = "Stage1_Task1";
    attr.priority = 25;
    if (osThreadNew(Stage1_Task1, NULL, &attr) == NULL)
    {
        printf("Failed to create Stage1_Task1!\r\n");
    }

    // 创建任务2
    attr.name = "Stage1_Task2";
    attr.priority = 25;
    if (osThreadNew(Stage1_Task2, NULL, &attr) == NULL)
    {
        printf("Failed to create Stage1_Task2!\r\n");
    }

    // 创建任务3
    attr.name = "Stage1_Task3";
    attr.priority = 25;
    if (osThreadNew(Stage1_Task3, NULL, &attr) == NULL)
    {
        printf("Failed to create Stage1_Task3!\r\n");
    }
}

APP_FEATURE_INIT(Experiment_Stage1);