#include <stdio.h>
#include <unistd.h>
#include <string.h>
#include "ohos_init.h"
#include "cmsis_os2.h"
#include "hal_bsp_ssd1306.h"
#include "hal_bsp_ssd1306_bmps.h"

// 前向声明：解决OLED_Task未定义报错
static void OLED_Task(void *arg);

static void OLED(void)
{
    osThreadAttr_t options;
    options.name = "OLED_Task";
    options.attr_bits = 0U;
    options.cb_mem = NULL;
    options.cb_size = 0U;
    options.stack_mem = NULL;
    options.stack_size = 1024U;
    options.priority = osPriorityNormal;

    osThreadId_t Task_ID;
    Task_ID = osThreadNew((osThreadFunc_t)OLED_Task, NULL, &options);
    if (Task_ID != NULL) {
        printf("Create OLED Task Success!\n");
    } else {
        printf("Create OLED Task Failed!\n");
    }
}

static void OLED_Task(void *arg)
{
    (void)arg; // 消除未使用参数警告
    uint8_t displayBuff[20] = {0};
    uint8_t hour = 11, min = 56, sec = 0;

    SSD1306_Init();  // OLED显示屏初始化
    SSD1306_CLS();   // 清屏
    SSD1306_ShowStr(0, 0, (uint8_t *)"    !!!QST!!!  ", 16);
    SSD1306_ShowStr(0, 3, (uint8_t *)"2024-08-06", 16);

    while (1)
    {
        sec++;
        if (sec > 59)
        {
            sec = 0;
            min++;
        }
        if (min > 59)
        {
            min = 0;
            hour++;
        }
        if (hour > 23)
        {
            hour = 0;
        }

        memset(displayBuff, 0, sizeof(displayBuff));
        sprintf((char *)displayBuff, "%02d:%02d:%02d", hour, min, sec);
        SSD1306_ShowStr(0, 2, displayBuff, 16);

        usleep(1000000); // 1秒延时，适配鸿蒙LiteOS
    }
}

APP_FEATURE_INIT(OLED);