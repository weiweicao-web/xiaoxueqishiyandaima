#include <stdio.h>
#include <string.h>
#include <unistd.h>
#include <stdlib.h>

#include "ohos_init.h"
#include "cmsis_os2.h"
#include "iot_gpio.h"
#include "hi_io.h"
#include "iot_pwm.h"
#include "hi_pwm.h"
#include "iot_uart.h"
#include "hi_uart.h"
#include "iot_errno.h"

#define UART_BUFF_SIZE 1000
#define GPS_UART_ID     HI_UART_IDX_2
#define GPS_TX_PIN      HI_IO_NAME_GPIO_11
#define GPS_RX_PIN      HI_IO_NAME_GPIO_12

// 结构体修正：latitude纬度，longitude经度（原代码写反）
typedef struct
{
    uint16_t latitude;        // 纬度 度
    uint16_t latitude_Min;    // 纬度 分
    uint16_t longitude;       // 经度 度
    uint16_t longitude_Min;   // 经度 分
    uint8_t flags;            // 定位有效标识 A=1 V=0
    uint8_t Northern;         // 北纬1 / 南纬0
    uint8_t East;             // 东经1 / 西经0
    int year;
    int month;
    int day;
    int hour;
    int minute;
    int second;
} GPS_INFO;

static uint8_t uart_buff[UART_BUFF_SIZE] = {0};
static GPS_INFO g_GPS_Store = {0};

/**
 * @brief 分割NMEA报文，按逗号取第n段字符串
 * @param buf NMEA原始字符串
 * @param idx 逗号分割下标
 * @param out 输出缓存
 * @param outLen 输出缓存长度
 */
static void NMEA_GetField(const char *buf, int idx, char *out, int outLen)
{
    memset(out, 0, outLen);
    int curIdx = 0;
    const char *p = buf;
    while (*p != '\0' && curIdx < idx)
    {
        if (*p == ',')
            curIdx++;
        p++;
    }
    if (curIdx != idx)
        return;
    int i = 0;
    while (*p != '\0' && *p != ',' && i < outLen - 1)
    {
        out[i++] = *p++;
    }
}

/**
 * @brief 解析GPRMC定位报文
 * @param nmeaBuf 完整NMEA一行字符串
 */
static void GPS_ParseGPRMC(const char *nmeaBuf)
{
    char tmp[64] = {0};
    // 0:$GPRMC, 1:UTC时间, 2:定位状态A/V, 3:纬度,4:N/S,5:经度,6:E/W
    NMEA_GetField(nmeaBuf, 1, tmp, sizeof(tmp));
    if (strlen(tmp) < 6)
        return;
    // UTC时间 HHMMSS
    int utcH = (tmp[0] - '0') * 10 + (tmp[1] - '0');
    int utcM = (tmp[2] - '0') * 10 + (tmp[3] - '0');
    int utcS = (tmp[4] - '0') * 10 + (tmp[5] - '0');
    // 东八区 +8小时
    g_GPS_Store.hour = utcH + 8;
    g_GPS_Store.minute = utcM;
    g_GPS_Store.second = utcS;

    // 定位状态
    NMEA_GetField(nmeaBuf, 2, tmp, sizeof(tmp));
    if (tmp[0] == 'A')
        g_GPS_Store.flags = 1;
    else
        g_GPS_Store.flags = 0;

    if (g_GPS_Store.flags == 0)
    {
        printf("GPS 无有效定位\n");
        return;
    }

    // 纬度 ddmm.mmmm
    NMEA_GetField(nmeaBuf, 3, tmp, sizeof(tmp));
    if (strlen(tmp) >= 4)
    {
        g_GPS_Store.latitude = (tmp[0] - '0') * 10 + (tmp[1] - '0');
        g_GPS_Store.latitude_Min = (tmp[2] - '0') * 10 + (tmp[3] - '0');
    }
    // N/S
    NMEA_GetField(nmeaBuf, 4, tmp, sizeof(tmp));
    if (tmp[0] == 'N')
    {
        g_GPS_Store.Northern = 1;
        printf("北纬 %d度%d分\n", g_GPS_Store.latitude, g_GPS_Store.latitude_Min);
    }
    else
    {
        g_GPS_Store.Northern = 0;
        printf("南纬 %d度%d分\n", g_GPS_Store.latitude, g_GPS_Store.latitude_Min);
    }

    // 经度 dddmm.mmmm
    NMEA_GetField(nmeaBuf, 5, tmp, sizeof(tmp));
    if (strlen(tmp) >= 5)
    {
        g_GPS_Store.longitude = (tmp[0] - '0') * 100 + (tmp[1] - '0') * 10 + (tmp[2] - '0');
        g_GPS_Store.longitude_Min = (tmp[3] - '0') * 10 + (tmp[4] - '0');
    }
    // E/W
    NMEA_GetField(nmeaBuf, 6, tmp, sizeof(tmp));
    if (tmp[0] == 'E')
    {
        g_GPS_Store.East = 1;
        printf("东经 %d度%d分\n", g_GPS_Store.longitude, g_GPS_Store.longitude_Min);
    }
    else
    {
        g_GPS_Store.East = 0;
        printf("西经 %d度%d分\n", g_GPS_Store.longitude, g_GPS_Store.longitude_Min);
    }
    printf("北京时间: %02d时%02d分%02d秒\n\n", g_GPS_Store.hour, g_GPS_Store.minute, g_GPS_Store.second);
}

static void GPS_Parameters(void)
{
    int readLen = IoTUartRead(GPS_UART_ID, uart_buff, UART_BUFF_SIZE - 1);
    if (readLen <= 0)
        return;
    uart_buff[readLen] = '\0'; // 字符串结束符，防止strstr越界

    // 查找完整GPRMC报文行
    char *gprmcPtr = strstr((char *)uart_buff, "$GPRMC");
    if (gprmcPtr == NULL)
    {
        memset(uart_buff, 0, UART_BUFF_SIZE);
        return;
    }
    // 找到换行符，截取单条完整报文
    char *lineEnd = strstr(gprmcPtr, "\r\n");
    if (lineEnd != NULL)
    {
        *lineEnd = '\0';
        GPS_ParseGPRMC(gprmcPtr);
    }
    memset(uart_buff, 0, UART_BUFF_SIZE);
}

// CMSIS-RTOS2 标准任务原型
static void UART_Task(void *arg)
{
    (void)arg;
    uint32_t ret;

    // IO初始化复用UART2
    IoTGpioInit(GPS_TX_PIN);
    IoTGpioInit(GPS_RX_PIN);
    hi_io_set_func(GPS_TX_PIN, HI_IO_FUNC_GPIO_11_UART2_TXD);
    hi_io_set_func(GPS_RX_PIN, HI_IO_FUNC_GPIO_12_UART2_RXD);

    IotUartAttribute uart_attr = {0};
    uart_attr.baudRate = 9600;
    uart_attr.dataBits = IOT_UART_DATA_BIT_8;
    uart_attr.stopBits = IOT_UART_STOP_BIT_1;
    uart_attr.parity = IOT_UART_PARITY_NONE;
    uart_attr.rxBlock = IOT_UART_BLOCK_STATE_BLOCK;

    ret = IoTUartInit(GPS_UART_ID, &uart_attr);
    if (ret != IOT_SUCCESS)
    {
        printf("Failed to init uart! Err code = %d\n", ret);
        return;
    }
    printf("GPS UART2 9600 init success, waiting GPS data...\n\n");

    while (1)
    {
        GPS_Parameters();
        osDelay(100); // 延长延时减少CPU占用，原10ms太快
    }
}

static void Uart_GPS(void)
{
    osThreadAttr_t attr = {0};
    attr.name = "UART_Task";
    attr.stack_size = 1024 * 10;
    attr.priority = 25;

    osThreadId_t tid = osThreadNew(UART_Task, NULL, &attr);
    if (tid == NULL)
    {
        printf("[GPS Example] Failed to create UART_Task!\n");
    }
}

APP_FEATURE_INIT(Uart_GPS);