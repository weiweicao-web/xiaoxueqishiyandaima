#include <stdio.h>
#include <unistd.h>
#include "ohos_init.h"
#include "cmsis_os2.h"
#include "iot_gpio.h"
#include "hi_io.h"

#define RGB_THREAD_STACK_SIZE   1024*4
#define RGB_THREAD1_PRIO        25
#define RGB_THREAD2_PRIO        25

static void *EC_Thread2(const char *);
static void *EC_Thread1(const char *);
static void EC_Thread(void)
{
    osThreadAttr_t attr;
    attr.attr_bits = 0U; //设置osThraedJoin是否可以使用
    attr.cb_mem = NULL; //控制块指针设置
    attr.cb_size = 0U; //控制块指针大小
    attr.stack_mem = NULL; //任务栈设置
    attr.stack_size = RGB_THREAD_STACK_SIZE;  //任务栈大小

    //创建任务1
    attr.name = "EC_Thread1";
    attr.priority = RGB_THREAD1_PRIO;
    if(osThreadNew((osThreadFunc_t)EC_Thread1,NULL,&attr) == NULL){
        printf("Failed to create EC_Thread1!\n");
    }

    //创建任务2
    attr.name = "EC_Thread2";
    attr.priority = RGB_THREAD2_PRIO;
    if(osThreadNew((osThreadFunc_t)EC_Thread2,NULL,&attr) == NULL){
        printf("Failed to create EC_Thread2!\n");
    }
}
static void *EC_Thread1(const char *arg)
{
    (void)arg;

    //初始化GPIO
    IoTGpioInit(HI_IO_NAME_GPIO_2);
    IoTGpioInit(HI_IO_NAME_GPIO_7);
    //IoTGpioInit(HI_IO_NAME_GPIO_8);

    //设置为普通GPIO功能
    hi_io_set_func(HI_IO_NAME_GPIO_2,HI_IO_FUNC_GPIO_2_GPIO);
    hi_io_set_func(HI_IO_NAME_GPIO_7,HI_IO_FUNC_GPIO_7_GPIO);
    //hi_io_set_func(HI_IO_NAME_GPIO_8,HI_IO_FUNC_GPIO_8_GPIO);

    //设置GPIO为输出模式
    IoTGpioSetDir(HI_IO_NAME_GPIO_2,IOT_GPIO_DIR_OUT);
    IoTGpioSetDir(HI_IO_NAME_GPIO_7,IOT_GPIO_DIR_OUT);
    //IoTGpioSetDir(HI_IO_NAME_GPIO_8,IOT_GPIO_DIR_OUT);

    //设置GPIO为输出低电平
    IoTGpioSetOutputVal(HI_IO_NAME_GPIO_2,IOT_GPIO_VALUE0);
    IoTGpioSetOutputVal(HI_IO_NAME_GPIO_7,IOT_GPIO_VALUE0);
    //IoTGpioSetOutputVal(HI_IO_NAME_GPIO_8,IOT_GPIO_VALUE0);

    while(1){
        printf("EC_Thread1 is running!!!\n");

        //点亮R灯
        IoTGpioSetOutputVal(HI_IO_NAME_GPIO_2,IOT_GPIO_VALUE1);
        IoTGpioSetOutputVal(HI_IO_NAME_GPIO_7,IOT_GPIO_VALUE0);
        //IoTGpioSetOutputVal(HI_IO_NAME_GPIO_8,IOT_GPIO_VALUE0);

        //延时3秒
        sleep(3);

        //点亮G灯
        IoTGpioSetOutputVal(HI_IO_NAME_GPIO_2,IOT_GPIO_VALUE0);
        IoTGpioSetOutputVal(HI_IO_NAME_GPIO_7,IOT_GPIO_VALUE1);
        //IoTGpioSetOutputVal(HI_IO_NAME_GPIO_8,IOT_GPIO_VALUE0);

        //延时3秒
        sleep(3);

        //点亮B灯
        IoTGpioSetOutputVal(HI_IO_NAME_GPIO_2,IOT_GPIO_VALUE0);
        IoTGpioSetOutputVal(HI_IO_NAME_GPIO_7,IOT_GPIO_VALUE0);
        //IoTGpioSetOutputVal(HI_IO_NAME_GPIO_8,IOT_GPIO_VALUE1);
        
        //延时3秒
        sleep(3);

    } 
    return NULL;
}
static void *EC_Thread2(const char *arg)
{
    (void)arg;

    //延时一秒使任务1执行
    sleep(1);

    while(1){
        
        printf("EC_Thread2 is running!!!\n");

        //延时3秒等待任务1执行完成
        sleep(3);
    }

    return NULL;
}
//启动任务
APP_FEATURE_INIT(EC_Thread);
