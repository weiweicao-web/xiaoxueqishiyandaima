#include <stdio.h>
#include <unistd.h>
#include "ohos_init.h"
#include "iot_gpio.h"
#include "hi_io.h"
void LED(void)
{
    //GPIO初始化
    IoTGpioInit(HI_IO_NAME_GPIO_6);

    //设置为普通GPIO功能
    hi_io_set_func(HI_IO_NAME_GPIO_6,HI_IO_FUNC_GPIO_6_GPIO);
    
    //GPIO设置为输出
    IoTGpioSetDir(HI_IO_NAME_GPIO_6,IOT_GPIO_DIR_OUT);
    
    //设置GPIO输出低电平
    IoTGpioSetOutputVal(HI_IO_NAME_GPIO_6,IOT_GPIO_VALUE0); 

    while(1){
        IoTGpioSetOutputVal(HI_IO_NAME_GPIO_6,IOT_GPIO_VALUE1);//点亮LED灯
        sleep(1);//系统休眠1秒
        
        IoTGpioSetOutputVal(HI_IO_NAME_GPIO_6,IOT_GPIO_VALUE0);//熄灭LED灯
        sleep(1);//系统休眠1秒
    }
}
//启动任务
APP_FEATURE_INIT(LED);