#include <stdio.h>
#include <unistd.h>
#include <string.h>
#include "ohos_init.h"
#include "cmsis_os2.h"
#include "config.h"
#include "mpu6050.h"

static void thread1(void *arg);

static void Mpu6050_demo(void)
{
  osThreadAttr_t attr;
  attr.attr_bits = 0U;
  attr.cb_mem = NULL;
  attr.cb_size = 0U;
  attr.stack_mem = NULL;
  attr.stack_size = 4096U;

  attr.name = "thread1";
  attr.priority = osPriorityNormal;
  osThreadId_t tid = osThreadNew((osThreadFunc_t)thread1, NULL, &attr);
  if (tid == NULL)
  {
    printf("Failed to create thread1!\n");
  }
  else
  {
    printf("Create MPU6050 Thread Success!\n");
  }
}

static void thread1(void *arg)
{
    (void)arg;
    hi_u32 ret;
    hi_s16 mpu_dates[7] = {0};
    hi_u8 mpu_ds[14] = {0};
    hi_u8 mpu_ln = 14;

    // 修正I2C引脚复用宏定义，GPIO14作为SCL
    hi_io_set_func(HI_IO_NAME_GPIO_10, HI_IO_FUNC_GPIO_10_I2C0_SDA);
    hi_io_set_func(HI_IO_NAME_GPIO_14, HI_IO_FUNC_GPIO_14_I2C0_SCL);

    ret = hi_i2c_init(HI_I2C_IDX_0, 400000U);
    if (ret != HI_ERR_SUCCESS)
    {
        printf("[hi_i2c_init] Failed \n");
    }
    Mpu6050_Init();

    while(1)
    {
      Mpu6050_Measure_By(mpu_ds, mpu_ln);
      Mpu6050_Measure_Sh(mpu_dates);
      printf("accel x=%d, accel y=%d, accel z=%d, gyro x=%d, gyro y=%d, gyro z=%d\n",
             mpu_dates[0], mpu_dates[1], mpu_dates[2],
             mpu_dates[3], mpu_dates[4], mpu_dates[5]);
      osDelay(1000);
    }
}

APP_FEATURE_INIT(Mpu6050_demo);