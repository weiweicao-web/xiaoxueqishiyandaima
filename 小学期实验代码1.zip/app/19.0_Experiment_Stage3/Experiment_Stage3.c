#include <stdio.h>
#include <string.h>
#include <unistd.h>
#include <stdlib.h>
#include "cmsis_os2.h"
#include "iot_errno.h"
#include "ohos_init.h"
#include "lwip/netif.h"
#include "lwip/netifapi.h"
#include "lwip/ip4_addr.h"
#include "lwip/api_shell.h"
#include "wifi_device.h"

static int g_staScanSuccess = 0;
static int g_ConnectSuccess = 0;
static int ssid_count = 0;

WifiEvent g_wifiEventHandler = {0};
WifiErrorCode error;

#define DEF_TIMEOUT 15
#define ONE_SECOND 1
#define SELECT_WLAN_PORT "wlan0"
#define SELECT_WIFI_SSID "Xiaomi_Civi_5_Pro"          // ⬅️ 改成你的WiFi名称
#define SELECT_WIFI_PASSWORD "sdg15244671368"  // ⬅️ 改成你的WiFi密码
#define SELECT_WIFI_SECURITYTYPE WIFI_SEC_TYPE_PSK

static void WiFiInit(void);
static void WaitScanResult(void);
static int WaitConnectResult(void);
static void OnWifiScanStateChangedHandler(int state, int size);
static void OnWifiConnectionChangedHandler(int state, WifiLinkedInfo *info);
static void OnHotspotStaJoinHandler(StationInfo *info);
static void OnHotspotStateChangedHandler(int state);
static void OnHotspotStaLeaveHandler(StationInfo *info);
static void WIFI_Task(void);

static void WIFI_CONN(void)
{
    osThreadAttr_t attr;
    attr.name = "WIFI_Task";
    attr.attr_bits = 0U;
    attr.cb_mem = NULL;
    attr.cb_size = 0U;
    attr.stack_mem = NULL;
    attr.stack_size = 10240;
    attr.priority = 24;

    if (osThreadNew((osThreadFunc_t)WIFI_Task, NULL, &attr) == NULL) {
        printf("Failed to create WIFI_Task!\n");
    }
}

static void WIFI_Task(void)
{
    WifiScanInfo *info = NULL;
    unsigned int size = WIFI_SCAN_HOTSPOT_LIMIT;
    static struct netif *g_lwip_netif = NULL;
    WifiDeviceConfig select_ap_config = {0};
    int found = 0;

    osDelay(200);
    printf("<-- System Init -->\r\n");

    WiFiInit();

    if (EnableWifi() != WIFI_SUCCESS) {
        printf("EnableWifi failed, error = %d\n", error);
        return;
    }

    if (IsWifiActive() == 0) {
        printf("Wifi station is not actived.\n");
        return;
    }

    info = (WifiScanInfo *)malloc(sizeof(WifiScanInfo) * WIFI_SCAN_HOTSPOT_LIMIT);
    if (info == NULL) {
        printf("Malloc failed!\n");
        return;
    }

    do {
        ssid_count = 0;
        g_staScanSuccess = 0;

        error = Scan();
        if (error != WIFI_SUCCESS) {
            printf("Scan failed, error = %d\n", error);
        }

        WaitScanResult();
        error = GetScanInfoList(info, &size);
        if (error != WIFI_SUCCESS) {
            printf("GetScanInfoList failed, error = %d\n", error);
        }
    } while (g_staScanSuccess != 1);

    printf("********************\n");
    for (uint8_t i = 0; i < ssid_count && i < WIFI_SCAN_HOTSPOT_LIMIT; i++) {
        printf("no:%03d, ssid:%-30s, rssi:%5d\n", i + 1, info[i].ssid, info[i].rssi / 100);
    }
    printf("********************\n");

    for (uint8_t i = 0; i < ssid_count && i < WIFI_SCAN_HOTSPOT_LIMIT; i++) {
        if (strcmp(SELECT_WIFI_SSID, info[i].ssid) == 0) {
            int result;
            printf("Select:%3d wireless, Waiting...\r\n", i + 1);

            strcpy(select_ap_config.ssid, info[i].ssid);
            strcpy(select_ap_config.preSharedKey, SELECT_WIFI_PASSWORD);
            select_ap_config.securityType = SELECT_WIFI_SECURITYTYPE;

            if (AddDeviceConfig(&select_ap_config, &result) == WIFI_SUCCESS) {
                if (ConnectTo(result) == WIFI_SUCCESS && WaitConnectResult() == 1) {
                    printf("WiFi connect succeed!\n");
                    g_lwip_netif = netifapi_netif_find(SELECT_WLAN_PORT);
                    found = 1;
                    break;
                }
            }
        }
    }

    if (!found) {
        printf("ERROR: No wifi as expected\n");
        free(info);
        return;
    }

    free(info);

    if (g_lwip_netif != NULL) {
        dhcp_start(g_lwip_netif);
        printf("Begin to DHCP\n");
    } else {
        printf("netif is NULL, DHCP start failed!\n");
        return;
    }

    for (;;) {
        if (dhcp_is_bound(g_lwip_netif) == ERR_OK) {
            printf("<-- DHCP state: OK -->\r\n");
            netifapi_netif_common(g_lwip_netif, dhcp_clients_info_show, NULL);
            break;
        }
        printf("<-- DHCP state: Inprogress -->\r\n");
        osDelay(100);
    }

    printf("WiFi connected successfully!\n");
    for (;;) {
        osDelay(100);
    }
}

static void WiFiInit(void)
{
    printf("<-- Wifi Init -->\n");
    g_wifiEventHandler.OnWifiScanStateChanged = OnWifiScanStateChangedHandler;
    g_wifiEventHandler.OnWifiConnectionChanged = OnWifiConnectionChangedHandler;
    g_wifiEventHandler.OnHotspotStaJoin = OnHotspotStaJoinHandler;
    g_wifiEventHandler.OnHotspotStaLeave = OnHotspotStaLeaveHandler;
    g_wifiEventHandler.OnHotspotStateChanged = OnHotspotStateChangedHandler;

    error = RegisterWifiEvent(&g_wifiEventHandler);
    if (error != WIFI_SUCCESS) {
        printf("Register wifi event fail! error=%d\n", error);
    } else {
        printf("Register wifi event succeed!\n");
    }
}

static void OnWifiScanStateChangedHandler(int state, int size)
{
    (void)state;
    if (size > 0) {
        ssid_count = size;
        g_staScanSuccess = 1;
        printf("Scan complete, found %d APs\n", size);
    }
}

static void OnWifiConnectionChangedHandler(int state, WifiLinkedInfo *info)
{
    (void)info;
    if (state > 0) {
        g_ConnectSuccess = 1;
        printf("Callback: wifi connected!\n");
    } else {
        printf("Callback: connect error, please check password\n");
    }
}

static void OnHotspotStaJoinHandler(StationInfo *info)
{
    (void)info;
    printf("STA join AP\n");
}

static void OnHotspotStaLeaveHandler(StationInfo *info)
{
    (void)info;
    printf("HotspotStaLeave\n");
}

static void OnHotspotStateChangedHandler(int state)
{
    printf("HotspotStateChanged: state is %d\n", state);
}

static void WaitScanResult(void)
{
    int scanTimeout = DEF_TIMEOUT;
    while (scanTimeout > 0) {
        sleep(ONE_SECOND);
        scanTimeout--;
        if (g_staScanSuccess == 1) {
            printf("WaitScanResult: success[%d]s\n", (DEF_TIMEOUT - scanTimeout));
            break;
        }
    }
    if (scanTimeout <= 0) {
        printf("WaitScanResult: timeout!\n");
    }
}

static int WaitConnectResult(void)
{
    int ConnectTimeout = DEF_TIMEOUT;
    while (ConnectTimeout > 0) {
        sleep(1);
        ConnectTimeout--;
        if (g_ConnectSuccess == 1) {
            printf("WaitConnectResult: success[%d]s\n", (DEF_TIMEOUT - ConnectTimeout));
            break;
        }
    }
    if (ConnectTimeout <= 0) {
        printf("WaitConnectResult: timeout!\n");
        return 0;
    }
    return 1;
}

APP_FEATURE_INIT(WIFI_CONN);