#include <stdio.h>
#include <string.h>
#include <stdlib.h>    // malloc free
#include "cmsis_os2.h"
#include "iot_errno.h"
#include "ohos_init.h"
#include "lwip/netif.h"
#include "lwip/netifapi.h"
#include "lwip/ip4_addr.h"
#include "lwip/dhcp.h"
#include "wifi_device.h"

// 增加volatile，防止编译器优化，回调与任务双向访问
static volatile int g_staScanSuccess = 0;
static volatile int g_ConnectSuccess = 0;
static volatile int ssid_count = 0;

WifiEvent g_wifiEventHandler = {0};
WifiErrorCode error;

#define DEF_TIMEOUT         15
#define SELECT_WLAN_PORT    "wlan0"
#define SELECT_WIFI_SSID    "QST-WIFI"
#define SELECT_WIFI_PASSWORD "qst654321"
#define SELECT_WIFI_SECURITYTYPE WIFI_SEC_TYPE_PSK

static void WiFiInit(void);
static void WaitSacnResult(void);
static int WaitConnectResult(void);
static void OnWifiScanStateChangedHandler(int state, int size);
static void OnWifiConnectionChangedHandler(int state, WifiLinkedInfo *info);
static void OnHotspotStaJoinHandler(StationInfo *info);
static void OnHotspotStateChangedHandler(int state);
static void OnHotspotStaLeaveHandler(StationInfo *info);

static void WIFI_Task(void *arg);  // 修正任务原型

static void WIFI_CONN(void)
{
    osThreadAttr_t attr;
    attr.name = "WIFI_Task";
    attr.attr_bits = 0U;
    attr.cb_mem = NULL;
    attr.cb_size = 0U;
    attr.stack_mem = NULL;
    attr.stack_size = 10240;
    attr.priority = 24;

    if (osThreadNew(WIFI_Task, NULL, &attr) == NULL) {
        printf("Failed to create WIFI_Task!\r\n");
    }
}

static void WIFI_Task(void *arg)
{
    (void)arg;
    WifiScanInfo *info = NULL;
    unsigned int size = WIFI_SCAN_HOTSPOT_LIMIT;
    static struct netif *g_lwip_netif = NULL;
    WifiDeviceConfig select_ap_config = {0};
    int retry_cnt = 0;

    osDelay(200);
    printf("<--System Init-->\r\n");

    WiFiInit();

    if (EnableWifi() != WIFI_SUCCESS) {
        printf("EnableWifi failed!\r\n");
        goto task_end;
    }

    if (IsWifiActive() == 0) {
        printf("Wifi station is not actived.\r\n");
        goto task_end;
    }

    info = malloc(sizeof(WifiScanInfo) * WIFI_SCAN_HOTSPOT_LIMIT);
    if (info == NULL) {
        printf("malloc scan info fail!\r\n");
        goto task_end;
    }

    // 扫描重试循环
    while (1)
    {
        ssid_count = 0;
        g_staScanSuccess = 0;
        g_ConnectSuccess = 0;

        printf("\r\nStart Scan WiFi...\r\n");
        error = Scan();
        if (error != WIFI_SUCCESS) {
            printf("Scan api fail, retry!\r\n");
            osDelay(2000);
            continue;
        }

        WaitSacnResult();
        if (g_staScanSuccess != 1) {
            printf("scan timeout, rescan\r\n");
            osDelay(2000);
            continue;
        }

        error = GetScanInfoList(info, &size);
        if (error != WIFI_SUCCESS) {
            printf("GetScanInfoList fail\r\n");
            osDelay(2000);
            continue;
        }

        printf("********************\r\n");
        for (uint8_t i = 0; i < ssid_count; i++) {
            printf("no:%03d, ssid:%-30s, rssi:%5d\r\n", i+1, info[i].ssid, info[i].rssi/100);
        }
        printf("********************\r\n");

        // 寻找目标WiFi
        int find_target = 0;
        int net_id = -1;
        for (uint8_t i = 0; i < ssid_count; i++) {
            if (strcmp(SELECT_WIFI_SSID, info[i].ssid) == 0) {
                printf("Find target AP: %s\r\n", info[i].ssid);
                find_target = 1;

                memset(&select_ap_config, 0, sizeof(select_ap_config));
                strcpy(select_ap_config.ssid, info[i].ssid);
                strcpy(select_ap_config.preSharedKey, SELECT_WIFI_PASSWORD);
                select_ap_config.securityType = SELECT_WIFI_SECURITYTYPE;

                if (AddDeviceConfig(&select_ap_config, &net_id) == WIFI_SUCCESS) {
                    printf("AddDeviceConfig ok, netid = %d\r\n", net_id);
                    if (ConnectTo(net_id) == WIFI_SUCCESS && WaitConnectResult() == 1) {
                        printf("WiFi connect succeed!\r\n");
                        g_lwip_netif = netifapi_netif_find(SELECT_WLAN_PORT);
                        goto wifi_connected;
                    }
                }
                break;
            }
        }

        if (!find_target) {
            printf("ERROR: No target wifi [%s] found\r\n", SELECT_WIFI_SSID);
        } else {
            printf("Connect AP failed, will retry\r\n");
        }

        retry_cnt++;
        osDelay(3000);
    }

wifi_connected:
    free(info);
    info = NULL;

    if (g_lwip_netif) {
        dhcp_start(g_lwip_netif);
        printf("begin to dhcp\r\n");
    }

    // 等待DHCP
    while (1) {
        if (dhcp_is_bound(g_lwip_netif) == ERR_OK) {
            printf("<-- DHCP state:OK -->\r\n");
#if 0
            // 如果编译报错直接注释下面这行
            netifapi_netif_common(g_lwip_netif, dhcp_clients_info_show, NULL);
#endif
            ip4_addr_t ip = g_lwip_netif->ip_addr.u_addr.ip4;
            printf("IP: %d.%d.%d.%d\r\n", ip4_addr1(&ip),ip4_addr2(&ip),ip4_addr3(&ip),ip4_addr4(&ip));
            break;
        }
        printf("<-- DHCP state:Inprogress -->\r\n");
        osDelay(500);
    }

    // 联网成功后主循环，可放业务代码
    while (1) {
        osDelay(1000);
    }

task_end:
    if (info) {
        free(info);
    }
    printf("WIFI Task exit!\r\n");
}

static void WiFiInit(void)
{
    printf("<--Wifi Init-->\r\n");
    memset(&g_wifiEventHandler, 0, sizeof(g_wifiEventHandler));
    g_wifiEventHandler.OnWifiScanStateChanged = OnWifiScanStateChangedHandler;
    g_wifiEventHandler.OnWifiConnectionChanged = OnWifiConnectionChangedHandler;
    g_wifiEventHandler.OnHotspotStaJoin = OnHotspotStaJoinHandler;
    g_wifiEventHandler.OnHotspotStaLeave = OnHotspotStaLeaveHandler;
    g_wifiEventHandler.OnHotspotStateChanged = OnHotspotStateChangedHandler;

    error = RegisterWifiEvent(&g_wifiEventHandler);
    if (error != WIFI_SUCCESS) {
        printf("register wifi event fail!\r\n");
    } else {
        printf("register wifi event succeed!\r\n");
    }
}

static void OnWifiScanStateChangedHandler(int state, int size)
{
    (void)state;
    if (size > 0) {
        ssid_count = size;
        g_staScanSuccess = 1;
    }
}

static void OnWifiConnectionChangedHandler(int state, WifiLinkedInfo *info)
{
    (void)info;
    // state >0 连接成功；state=0断开
    if (state > 0) {
        g_ConnectSuccess = 1;
        printf("callback: wifi connect success\r\n");
    } else {
        g_ConnectSuccess = 0;
        printf("callback: wifi disconnect or password error!\r\n");
    }
}

static void OnHotspotStaJoinHandler(StationInfo *info)
{
    (void)info;
    printf("STA join AP\r\n");
}

static void OnHotspotStaLeaveHandler(StationInfo *info)
{
    (void)info;
    printf("HotspotStaLeave\r\n");
}

static void OnHotspotStateChangedHandler(int state)
{
    printf("HotspotStateChanged:state is %d.\r\n", state);
}

static void WaitSacnResult(void)
{
    int scanTimeout = DEF_TIMEOUT;
    while (scanTimeout > 0) {
        osDelay(1000);
        scanTimeout--;
        if (g_staScanSuccess == 1) {
            printf("WaitSacnResult:wait success[%d]s\r\n", DEF_TIMEOUT - scanTimeout);
            break;
        }
    }
    if (scanTimeout <= 0) {
        printf("WaitSacnResult:timeout!\r\n");
    }
}

static int WaitConnectResult(void)
{
    int ConnectTimeout = DEF_TIMEOUT;
    while (ConnectTimeout > 0) {
        osDelay(1000);
        ConnectTimeout--;
        if (g_ConnectSuccess == 1) {
            printf("WaitConnectResult:wait success[%d]s\r\n", DEF_TIMEOUT - ConnectTimeout);
            return 1;
        }
    }
    printf("WaitConnectResult:connect timeout!\r\n");
    return 0;
}

APP_FEATURE_INIT(WIFI_CONN);