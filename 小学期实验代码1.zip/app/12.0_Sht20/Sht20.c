#include <stdio.h>
#include <unistd.h>
#include <string.h>
#include "ohos_init.h"
#include "cmsis_os2.h"
#include "hal_bsp_sht20.h"

// 函数前向声明，解决隐式定义报错
static void Sht20_Task1(void *arg);
static void Sht20_Task2(void *arg);
static void Sht20_Task3(void *arg);

osSemaphoreId_t sem1;

static void Sht20(void)
{
    osThreadAttr_t attr;
    attr.attr_bits = 0U;
    attr.cb_mem = NULL;
    attr.cb_size = 0U;
    attr.stack_mem = NULL;
    attr.stack_size = 4096U;
    attr.name = "Sht20_Task1";
    attr.priority = osPriorityNormal;

    osThreadId_t task1 = osThreadNew((osThreadFunc_t)Sht20_Task1, NULL, &attr);
    if (task1 == NULL) {
        printf("Failed to create Sht20_Task1!\n");
    }

    attr.name = "Sht20_Task2";
    osThreadId_t task2 = osThreadNew((osThreadFunc_t)Sht20_Task2, NULL, &attr);
    if (task2 == NULL) {
        printf("Failed to create Sht20_Task2!\n");
    }

    attr.name = "Sht20_Task3";
    osThreadId_t task3 = osThreadNew((osThreadFunc_t)Sht20_Task3, NULL, &attr);
    if (task3 == NULL) {
        printf("Failed to create Sht20_Task3!\n");
    }

    // 创建二值/计数信号量：最大4，初始0
    sem1 = osSemaphoreNew(4, 0, NULL);
    if (sem1 == NULL) {
        printf("Failed to create Semaphore1!\n");
    }
}

static void Sht20_Task1(void *arg)
{
    (void)arg;
    while (1)
    {
        // 一次性释放2个信号量，同时唤醒Task2、Task3
        osSemaphoreRelease(sem1);
        osSemaphoreRelease(sem1);
        printf("Sht20_Task1 has released sem1!\n");

        osDelay(3000); // 3000ms = 3秒，原注释300写错
    }
}

static void Sht20_Task2(void *arg)
{
    (void)arg;
    float temperature = 0.0f, humidity = 0.0f;
    SHT20_Init(); // SHT20温湿度传感器初始化

    while (1)
    {
        // 永久阻塞等待信号量
        osSemaphoreAcquire(sem1, osWaitForever);
        SHT20_ReadData(&temperature, &humidity);
        printf("temperature = %.2f; humidity = %.2f\r\n", temperature, humidity);
        printf("Sht20_Task2 has gotten sem1!\n");
        osDelay(10); // 10ms延时
    }
}

static void Sht20_Task3(void *arg)
{
    (void)arg;
    while (1)
    {
        osSemaphoreAcquire(sem1, osWaitForever);
        printf("Sht20_Task3 has gotten sem1!\n");
        osDelay(10); // 10ms延时
    }
}

APP_FEATURE_INIT(Sht20);